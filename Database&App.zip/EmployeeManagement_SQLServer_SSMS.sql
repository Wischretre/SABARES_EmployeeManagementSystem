USE [master]
GO
/****** Object:  Database [EmployeeManagementDB]    Script Date: 11/08/2026 07:28:25 PM ******/
CREATE DATABASE [EmployeeManagementDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'EmployeeManagementDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA\EmployeeManagementDB.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'EmployeeManagementDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA\EmployeeManagementDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [EmployeeManagementDB] SET COMPATIBILITY_LEVEL = 170
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [EmployeeManagementDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [EmployeeManagementDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [EmployeeManagementDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [EmployeeManagementDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [EmployeeManagementDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET  ENABLE_BROKER 
GO
ALTER DATABASE [EmployeeManagementDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [EmployeeManagementDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [EmployeeManagementDB] SET  MULTI_USER 
GO
ALTER DATABASE [EmployeeManagementDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [EmployeeManagementDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [EmployeeManagementDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [EmployeeManagementDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [EmployeeManagementDB] SET OPTIMIZED_LOCKING = OFF 
GO
ALTER DATABASE [EmployeeManagementDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [EmployeeManagementDB] SET QUERY_STORE = ON
GO
ALTER DATABASE [EmployeeManagementDB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [EmployeeManagementDB]
GO
USE [EmployeeManagementDB]
GO
/****** Object:  Sequence [dbo].[EmployeeNumberSequence]    Script Date: 11/08/2026 07:28:26 PM ******/
CREATE SEQUENCE [dbo].[EmployeeNumberSequence] 
 AS [int]
 START WITH 1
 INCREMENT BY 1
 MINVALUE -2147483648
 MAXVALUE 2147483647
 CACHE 
GO
/****** Object:  Table [dbo].[EmployeeContacts]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeContacts](
	[EmployeeId] [varchar](15) NOT NULL,
	[Email] [varchar](150) NOT NULL,
	[Phone] [varchar](20) NULL,
	[Address] [varchar](255) NULL,
 CONSTRAINT [PK_EmployeeContacts] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_EmployeeContacts_Email] UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmployeeEmployment]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeEmployment](
	[EmployeeId] [varchar](15) NOT NULL,
	[DepartmentId] [int] NULL,
	[JobTitle] [varchar](100) NOT NULL,
	[EmploymentStatus] [varchar](20) NOT NULL,
	[HireDate] [date] NOT NULL,
	[Salary] [decimal](12, 2) NOT NULL,
 CONSTRAINT [PK_EmployeeEmployment] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Departments]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Departments](
	[DepartmentId] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentCode] [varchar](20) NOT NULL,
	[DepartmentName] [varchar](100) NOT NULL,
 CONSTRAINT [PK_Departments] PRIMARY KEY CLUSTERED 
(
	[DepartmentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Departments_Code] UNIQUE NONCLUSTERED 
(
	[DepartmentCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Departments_Name] UNIQUE NONCLUSTERED 
(
	[DepartmentName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employees]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employees](
	[EmployeeId] [varchar](15) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[MiddleName] [varchar](50) NULL,
	[LastName] [varchar](50) NOT NULL,
	[Sex] [varchar](10) NOT NULL,
	[BirthDate] [date] NOT NULL,
 CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_EmployeeDirectory]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   VIEW [dbo].[vw_EmployeeDirectory]
AS
SELECT
    e.EmployeeId,
    e.FirstName,
    e.MiddleName,
    e.LastName,
    CONCAT(e.FirstName, ' ', e.LastName) AS FullName,
    e.Sex,
    e.BirthDate,
    DATEDIFF(YEAR, e.BirthDate, GETDATE())
        - CASE WHEN DATEADD(YEAR, DATEDIFF(YEAR, e.BirthDate, GETDATE()), e.BirthDate) > CAST(GETDATE() AS DATE)
               THEN 1 ELSE 0 END AS Age,
    c.Email,
    c.Phone,
    c.Address,
    em.DepartmentId,
    d.DepartmentName,
    em.JobTitle,
    em.EmploymentStatus,
    em.HireDate,
    em.Salary
FROM dbo.Employees AS e
INNER JOIN dbo.EmployeeContacts AS c ON c.EmployeeId = e.EmployeeId
INNER JOIN dbo.EmployeeEmployment AS em ON em.EmployeeId = e.EmployeeId
LEFT JOIN dbo.Departments AS d ON d.DepartmentId = em.DepartmentId;
GO
/****** Object:  Table [dbo].[EmploymentHistory]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmploymentHistory](
	[HistoryId] [bigint] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [varchar](15) NOT NULL,
	[CompanyName] [varchar](150) NOT NULL,
	[JobTitle] [varchar](100) NOT NULL,
	[EmploymentType] [varchar](20) NOT NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NULL,
	[ReasonForLeaving] [varchar](255) NULL,
	[Notes] [varchar](max) NULL,
 CONSTRAINT [PK_EmploymentHistory] PRIMARY KEY CLUSTERED 
(
	[HistoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Employees_LastName_First]    Script Date: 11/08/2026 07:28:26 PM ******/
CREATE NONCLUSTERED INDEX [IX_Employees_LastName_First] ON [dbo].[Employees]
(
	[LastName] ASC,
	[FirstName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_EmploymentHistory_Employee]    Script Date: 11/08/2026 07:28:26 PM ******/
CREATE NONCLUSTERED INDEX [IX_EmploymentHistory_Employee] ON [dbo].[EmploymentHistory]
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Employees] ADD  CONSTRAINT [DF_Employees_EmployeeId]  DEFAULT ('EMP-'+right('000000'+CONVERT([varchar](6),NEXT VALUE FOR [dbo].[EmployeeNumberSequence]),(6))) FOR [EmployeeId]
GO
ALTER TABLE [dbo].[EmployeeContacts]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeContacts_Employees] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employees] ([EmployeeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmployeeContacts] CHECK CONSTRAINT [FK_EmployeeContacts_Employees]
GO
ALTER TABLE [dbo].[EmployeeEmployment]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeEmployment_Departments] FOREIGN KEY([DepartmentId])
REFERENCES [dbo].[Departments] ([DepartmentId])
GO
ALTER TABLE [dbo].[EmployeeEmployment] CHECK CONSTRAINT [FK_EmployeeEmployment_Departments]
GO
ALTER TABLE [dbo].[EmployeeEmployment]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeEmployment_Employees] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employees] ([EmployeeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmployeeEmployment] CHECK CONSTRAINT [FK_EmployeeEmployment_Employees]
GO
ALTER TABLE [dbo].[EmploymentHistory]  WITH CHECK ADD  CONSTRAINT [FK_EmploymentHistory_Employees] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employees] ([EmployeeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmploymentHistory] CHECK CONSTRAINT [FK_EmploymentHistory_Employees]
GO
ALTER TABLE [dbo].[EmployeeEmployment]  WITH CHECK ADD  CONSTRAINT [CK_EmployeeEmployment_Salary] CHECK  (([Salary]>=(0)))
GO
ALTER TABLE [dbo].[EmployeeEmployment] CHECK CONSTRAINT [CK_EmployeeEmployment_Salary]
GO
ALTER TABLE [dbo].[EmployeeEmployment]  WITH CHECK ADD  CONSTRAINT [CK_EmployeeEmployment_Status] CHECK  (([EmploymentStatus]='Terminated' OR [EmploymentStatus]='Resigned' OR [EmploymentStatus]='On Leave' OR [EmploymentStatus]='Active'))
GO
ALTER TABLE [dbo].[EmployeeEmployment] CHECK CONSTRAINT [CK_EmployeeEmployment_Status]
GO
ALTER TABLE [dbo].[Employees]  WITH CHECK ADD  CONSTRAINT [CK_Employees_Sex] CHECK  (([Sex]='Other' OR [Sex]='Female' OR [Sex]='Male'))
GO
ALTER TABLE [dbo].[Employees] CHECK CONSTRAINT [CK_Employees_Sex]
GO
ALTER TABLE [dbo].[EmploymentHistory]  WITH CHECK ADD  CONSTRAINT [CK_History_Dates] CHECK  (([EndDate] IS NULL OR [EndDate]>=[StartDate]))
GO
ALTER TABLE [dbo].[EmploymentHistory] CHECK CONSTRAINT [CK_History_Dates]
GO
ALTER TABLE [dbo].[EmploymentHistory]  WITH CHECK ADD  CONSTRAINT [CK_History_Type] CHECK  (([EmploymentType]='Internship' OR [EmploymentType]='Contract' OR [EmploymentType]='Part-Time' OR [EmploymentType]='Full-Time'))
GO
ALTER TABLE [dbo].[EmploymentHistory] CHECK CONSTRAINT [CK_History_Type]
GO
/****** Object:  StoredProcedure [dbo].[usp_Employee_Create]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ---------- 6. Employee procedures (same parameters as before) ---------- */
CREATE PROCEDURE [dbo].[usp_Employee_Create]
    @FirstName        VARCHAR(50),
    @MiddleName       VARCHAR(50) = NULL,
    @LastName         VARCHAR(50),
    @Sex              VARCHAR(10),
    @BirthDate        DATE,
    @Email            VARCHAR(150),
    @Phone            VARCHAR(20) = NULL,
    @Address          VARCHAR(255) = NULL,
    @DepartmentId     INT = NULL,
    @JobTitle         VARCHAR(100),
    @EmploymentStatus VARCHAR(20),
    @HireDate         DATE,
    @Salary           DECIMAL(12,2),
    @EmployeeId       VARCHAR(15) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    IF @HireDate < @BirthDate THROW 50030, N'Hire date cannot be before birth date.', 1;

    DECLARE @Inserted TABLE (EmployeeId VARCHAR(15));

    BEGIN TRY
        BEGIN TRAN;

        INSERT dbo.Employees (FirstName, MiddleName, LastName, Sex, BirthDate)
        OUTPUT inserted.EmployeeId INTO @Inserted
        VALUES (@FirstName, @MiddleName, @LastName, @Sex, @BirthDate);

        SELECT @EmployeeId = EmployeeId FROM @Inserted;

        INSERT dbo.EmployeeContacts (EmployeeId, Email, Phone, Address)
        VALUES (@EmployeeId, @Email, @Phone, @Address);

        INSERT dbo.EmployeeEmployment (EmployeeId, DepartmentId, JobTitle, EmploymentStatus, HireDate, Salary)
        VALUES (@EmployeeId, @DepartmentId, @JobTitle, @EmploymentStatus, @HireDate, @Salary);

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO
/****** Object:  StoredProcedure [dbo].[usp_Employee_Delete]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Employee_Delete]
    @EmployeeId VARCHAR(15)
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM dbo.Employees WHERE EmployeeId = @EmployeeId;   -- cascades to contacts, employment, and history
END;
GO
/****** Object:  StoredProcedure [dbo].[usp_Employee_Read]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Employee_Read]
    @EmployeeId VARCHAR(15)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM dbo.vw_EmployeeDirectory WHERE EmployeeId = @EmployeeId;
END;
GO
/****** Object:  StoredProcedure [dbo].[usp_Employee_Search]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Employee_Search]
    @SearchText       VARCHAR(100) = NULL,
    @DepartmentId     INT = NULL,
    @EmploymentStatus VARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT *
    FROM dbo.vw_EmployeeDirectory
    WHERE (@SearchText IS NULL
           OR EmployeeId LIKE '%' + @SearchText + '%'
           OR FullName   LIKE '%' + @SearchText + '%'
           OR JobTitle   LIKE '%' + @SearchText + '%')
      AND (@DepartmentId IS NULL OR DepartmentId = @DepartmentId)
      AND (@EmploymentStatus IS NULL OR EmploymentStatus = @EmploymentStatus)
    ORDER BY EmployeeId;
END;
GO
/****** Object:  StoredProcedure [dbo].[usp_Employee_Update]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Employee_Update]
    @EmployeeId       VARCHAR(15),
    @FirstName        VARCHAR(50),
    @MiddleName       VARCHAR(50) = NULL,
    @LastName         VARCHAR(50),
    @Sex              VARCHAR(10),
    @BirthDate        DATE,
    @Email            VARCHAR(150),
    @Phone            VARCHAR(20) = NULL,
    @Address          VARCHAR(255) = NULL,
    @DepartmentId     INT = NULL,
    @JobTitle         VARCHAR(100),
    @EmploymentStatus VARCHAR(20),
    @HireDate         DATE,
    @Salary           DECIMAL(12,2)
AS
BEGIN
    SET NOCOUNT ON;
    IF @HireDate < @BirthDate THROW 50030, N'Hire date cannot be before birth date.', 1;

    BEGIN TRY
        BEGIN TRAN;

        UPDATE dbo.Employees
        SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName,
            Sex = @Sex, BirthDate = @BirthDate
        WHERE EmployeeId = @EmployeeId;

        IF @@ROWCOUNT = 0 THROW 50031, N'Employee not found.', 1;

        UPDATE dbo.EmployeeContacts
        SET Email = @Email, Phone = @Phone, Address = @Address
        WHERE EmployeeId = @EmployeeId;

        UPDATE dbo.EmployeeEmployment
        SET DepartmentId = @DepartmentId, JobTitle = @JobTitle,
            EmploymentStatus = @EmploymentStatus, HireDate = @HireDate, Salary = @Salary
        WHERE EmployeeId = @EmployeeId;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO
/****** Object:  StoredProcedure [dbo].[usp_EmployeeHistory_Create]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EmployeeHistory_Create]
    @EmployeeId       VARCHAR(15),
    @CompanyName      VARCHAR(150),
    @JobTitle         VARCHAR(100),
    @EmploymentType   VARCHAR(20),
    @StartDate        DATE,
    @EndDate          DATE = NULL,
    @ReasonForLeaving VARCHAR(255) = NULL,
    @Notes            VARCHAR(MAX) = NULL
AS
SET NOCOUNT ON;
INSERT INTO dbo.EmploymentHistory
    (EmployeeId, CompanyName, JobTitle, EmploymentType, StartDate, EndDate, ReasonForLeaving, Notes)
VALUES
    (@EmployeeId, @CompanyName, @JobTitle, @EmploymentType, @StartDate, @EndDate, @ReasonForLeaving, @Notes);
GO
/****** Object:  StoredProcedure [dbo].[usp_EmployeeHistory_Delete]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EmployeeHistory_Delete]
    @HistoryId BIGINT
AS
SET NOCOUNT ON;
DELETE FROM dbo.EmploymentHistory WHERE HistoryId = @HistoryId;
GO
/****** Object:  StoredProcedure [dbo].[usp_EmployeeHistory_ReadByEmployee]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ---------- Employment history stored procedures ---------- */
CREATE PROCEDURE [dbo].[usp_EmployeeHistory_ReadByEmployee]
    @EmployeeId VARCHAR(15)
AS
SET NOCOUNT ON;
SELECT * FROM dbo.EmploymentHistory
WHERE EmployeeId = @EmployeeId
ORDER BY StartDate DESC;
GO
/****** Object:  StoredProcedure [dbo].[usp_EmployeeHistory_Update]    Script Date: 11/08/2026 07:28:26 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_EmployeeHistory_Update]
    @HistoryId        BIGINT,
    @CompanyName      VARCHAR(150),
    @JobTitle         VARCHAR(100),
    @EmploymentType   VARCHAR(20),
    @StartDate        DATE,
    @EndDate          DATE = NULL,
    @ReasonForLeaving VARCHAR(255) = NULL,
    @Notes            VARCHAR(MAX) = NULL
AS
SET NOCOUNT ON;
UPDATE dbo.EmploymentHistory
SET CompanyName = @CompanyName, JobTitle = @JobTitle, EmploymentType = @EmploymentType,
    StartDate = @StartDate, EndDate = @EndDate,
    ReasonForLeaving = @ReasonForLeaving, Notes = @Notes
WHERE HistoryId = @HistoryId;
GO
USE [master]
GO
ALTER DATABASE [EmployeeManagementDB] SET  READ_WRITE 
GO
